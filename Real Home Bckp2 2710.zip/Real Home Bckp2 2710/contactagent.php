<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="styles/contactusstyle.css">
	<title>Real Home</title>
</head>
<body>

	<center>
		<?php
			session_start();
			include "connection.php";

			function isLoggedInemail(){
				
				if (isset($_SESSION["user_id"])){
					$user_id = $_SESSION['user_id'];
					$stmt = "SELECT * FROM users WHERE user_id = $user_id";
					$exec = mysqli_query($conn, $stmt);
					if (mysqli_num_rows($exec) > 0){
						$fetch = mysqli_fetch_assoc($exec);
						$useremail = $fetch["email"];
						return $useremail;
					}
				}
				else{
					return "";
				}
			}
			function isLoggedInname(){

				if (isset($_SESSION["user_id"])){
					$username = $_SESSION['username'];
					return $username;
				}
				else{
					return "";
				}
			}
		?>
		<div class="signin">
			<center>
			<h1>Contact Us</h1><hr><br>
			<form action="phpmailer/emailagent.php" name="contact" method="POST">
			<input type="hidden" name="agentem" value="<?php echo $_GET['agentemail']; ?>">
			<input type="text" name="fname" placeholder="Name" 
				value="<?php echo isLoggedinname(); ?>" required>
			<input type="Email" name="email" id="email" placeholder="Email" value="<?php //echo isLoggedInemail(); ?>" required><br>
			<input type="text" name="subject" id="subject" value="Esate Agent Needed" required><br><br>
			<textarea name="message" value="Hello there, I am in need of your services." class="mess" required></textarea>
			<input type="submit" name="send" id="submit" value="Send" class="submit">
			</form>
			<a href="index.php"><</a>
			</center>
		</div>
	</center>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale= 1.0">
	<title>Real Home</title>
	<link rel="stylesheet" type="text/css" href="styles/resultsstyle.css?v=1.0">
	<script type="text/javascript" src="scripts/results.js" async defer></script>
</head>
<body>
	<header class="top" id="top">
	<h1>Real Home</h1>
	<nav class="bottom">
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="contactus.html">Contact Us</a></li>
			<li>
				<?php
					session_start();
					include 'connection.php';
					if (isset($_SESSION["user_id"])){
						$user_id = $_SESSION['user_id'];
						echo "<a href='profilepage.php'>You</a>";
					}
					else{
						echo "<a href='loginpage.html'>Sign In</a>";
					}
				?>
			</li>
		</ul>
	</nav>
	</header><br>
	<div class="middle" id="middle">
		<center>
			<form name="searchfor" action="search.php" method="GET">
				<input type="search" name="search" placeholder="Search for properties"><br>
				<button type="submit" id="results" name="go">Search</button><br><br>
			</form>
			<button id="filter" class="filter" name="filter">Filter</button>
		</center>
		<?php
			$stmt = "SELECT * FROM properties";
					$prep = mysqli_prepare($conn,$stmt);
					mysqli_stmt_execute($prep);
					$res = mysqli_stmt_get_result($prep);

					if (mysqli_num_rows($res) > 0){
					
						while ($fetch = mysqli_fetch_assoc($res)){
							$propid = $fetch["prop_id"];
							$lister = ["user_id"];
							$propname = $fetch["name"];
							$propprice = $fetch["price"];
							$proptype = $fetch["proptype"];
							$beds = $fetch["bedrooms"];
							$baths = $fetch["bathrooms"];

							$lister = "SELECT * FROM users WHERE user_id = '$user_id'";
							$execlister = mysqli_query($conn, $lister);
							$fetchlister = mysqli_fetch_assoc($execlister);
							$listername = $fetchlister["username"];
							$surname = $fetchlister["surname"];				
							$lstimgstmt = "SELECT filename FROM images WHERE prop_id = ?";
							$lstimgprep = mysqli_prepare($conn, $lstimgstmt);
							mysqli_stmt_bind_param($lstimgprep,"i", $propid);
							mysqli_stmt_execute($lstimgprep);
							$lstimgres = mysqli_stmt_get_result($lstimgprep);
							if (mysqli_num_rows($lstimgres) > 0){
								$imgfetch = mysqli_fetch_assoc($lstimgres);
								$img = $imgfetch["filename"];
								$imgpath = "./propimages/" . basename($img);
								echo "<a href='property.php'>
									<div class='prop'>
									<div class='img'>
									<img src='$imgpath'>
									</div>
									<h3 id='pname'>$propname</h3>
									<p id='status'>$proptype</p>
									<p id='aname'>Listed By $listername $surname</p>
									<p id='price'>R$propprice</p>
									<p>Bedrooms: </p>
									<p>Bathrooms: </p><br>
								</div></a><br>";
							}}
					}
		?>
		
	</div>
	
	<div class="filterbox" id="filterbox">
		<center>
		<button class="back" id="back">X</button>
		<h2>Refine Results</h2><hr><br>
		<form name="refine" action="filter.php" method="GET">
			<select id="proptype" class="sel">
				<option>Property type</option>
				<option value="all">All</option>
				<option value="Aparment" id="aparment">Apartment</option>
				<option value="House" id="house">House</option>
				<option value="Commercial" id="commercial">Commercial</option>
				<option value="Plot" id="plot">Plot</option>
				<!--Include PHP code for all types from database on testing-->
			</select>
			<select class="sel">
				<option>Min Price</option>
			</select>

			<select class="sel">
				<option>Max Price</option>
			</select><br>

			<div class="primary">
				<div>
					<label for="bedrooms">Bedrooms</label>
					<input type="Number" name="bedrooms" id="bedrooms" class="bedrooms"  min="1"><br>
				</div>

				<div>
					<label for="bathrooms">Bathrooms</label>
					<input type="Number" name="bathrooms" id="bathrooms"  min="1" ><br>
				</div>

				<div>
					<label for="garages">Garages</label>
					<input type="Number" name="garages" id="garages"  min="1"><br>
				</div>

				<div>
					<label for="parkings">Parkings</label>
					<input type="Number" name="parkings" id="garages"  min="1"><br>
				</div>

				<div>
					<label for="stories">Stories</label>
					<input type="Number" name="stories" id="stories"  min="1"><br>
				</div>
			</div>

			<h3>Amenities</h3><hr class="sub">

			<div class="amenities">
				<div>
				<input type="checkbox" name="pool" value="yes" id="swpool" class="check"><label for="pool">Pool</label><br>
				</div>

				<div>
				<input type="checkbox" name="Electricity" value="yes" id="electricity" class="check"><label for="electricity">Electricity Included</label><br>
				</div>

				<div>
				<input type="checkbox" name="water" value="yes" id="water" class="check"><label for="water">Water Included</label><br>
				</div>

				<div>
				<input type="checkbox" name="pfriendly" value="yes" id="petf" class="check"><label for="pfriendly">Pet friendly</label><br>
				</div>

				<div>
				<input type="checkbox" name="balcony" value="yes" id="balcony" class="check"><label for="balcony">Balcony</label><br>
				</div>

				<div>
				<input type="checkbox" name="furnished" value="yes" id="furnished" class="check"><label for="furnished">Furnished</label><br>
				</div>
			</div>

			<h3>Security</h3><hr class="sub">
			<div class="security">
				<div>
				<input type="checkbox" name="elecfence" value="yes" id="swpool" class="check"><label for="elecfence">Electric fence</label><br>
				</div>

				<div>
				<input type="checkbox" name="alarm" value="yes" id="alarm" class="check"><label for="alarm">Alarm</label><br>
				</div>

				<div>
				<input type="checkbox" name="accessgate" value="yes" id="gate" class="check"><label for="accessgate">Access Gate</label><br>
				</div>

				<div>
				<input type="checkbox" name="secpost" value="yes" id="secpost" class="check"><label for="secpost">Security Post</label><br>
				</div>

			</div><br>
			<button type="submit" name="refine">Refine</button><br>
		</form>
		</center>
	</div>
</body>
</html>
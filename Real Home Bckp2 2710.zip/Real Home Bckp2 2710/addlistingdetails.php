<?php
	session_start();
	include "connection.php";
    if (isset($_SESSION['user_id'])){
        $user_id = $_SESSION['user_id'];
    }
    else{
        header("Location: index.php");
    }


    if (isset($_POST['submit'])) { // Corrected the typo
        $proptype = htmlspecialchars(trim($_POST['proptype']));
        $listingtype = htmlspecialchars(trim($_POST['listingtype']));
        $listingdate = htmlspecialchars(trim($_POST['date']));
        $propname = htmlspecialchars(trim($_POST['propname']));
        $propaddress = htmlspecialchars(trim($_POST['propaddress']));
        $province = htmlspecialchars(trim($_POST['province']));
        $city = htmlspecialchars(trim($_POST['city']));
        $suburb = htmlspecialchars(trim($_POST['suburb']));
        $numbedrooms = htmlspecialchars(trim($_POST['bedrooms']));
        $numbathrooms = htmlspecialchars(trim($_POST['bathrooms']));
        $garages = htmlspecialchars(trim($_POST['garages']));
        $stories = htmlspecialchars(trim($_POST['stories']));
        $price = htmlspecialchars(trim($_POST['propprice']));
        $area = htmlspecialchars(trim($_POST['area']));
        $description = htmlspecialchars($_POST['description']);
        $furnished = isset($_POST['furnished']) ? 'Yes' : 'No';
        $kitchen = isset($_POST['kitchen']) ? 'Yes' : 'No';
        $lounge = isset($_POST['lounge']) ? 'Yes' : 'No';
        $diningarea = isset($_POST['dining']) ? 'Yes' : 'No';
        $balcony = isset($_POST['balcony']) ? 'Yes' : 'No';
        $carport = isset($_POST['carport']) ? 'Yes' : 'No';
        $parking = isset($_POST['parking']) ? 'Yes' : 'No';
        $pavement = isset($_POST['pavement']) ? 'Yes' : 'No';
        $garden = isset($_POST['garden']) ? 'Yes' : 'No';
        $fenced = isset($_POST['fenced']) ? 'Yes' : 'No';
        $water = isset($_POST['water']) ? 'Yes' : 'No';
        $electricity = isset($_POST['electricity']) ? 'Yes' : 'No';
        $pool = isset($_POST['pool']) ? 'Yes' : 'No';
        $ensuite = isset($_POST['ensuite']) ? 'Yes' : 'No';
        $coords = $_POST['coords'];

        $stmt = "INSERT INTO properties(user_id,name,proptype,listingtype,address,province,city,location,suburb,listingdate,bedrooms,bathrooms,garages,stories,price,area,furnished,kitchen,lounge,diningarea,balcony,carport,parking,pavement,garden,fenced,water,electricity,pool,ensuite,description) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        $prep = mysqli_prepare($conn, $stmt);
        mysqli_stmt_bind_param($prep,"isssssssssiiiiidsssssssssssssss",$user_id,$propname,$proptype,$listingtype,$propaddress,$province,$city,$coords,$suburb,$listingdate,$numbedrooms,$numbathrooms,$garages,$stories,$price,$area,$furnished,$kitchen,$lounge,$diningarea,$balcony,$carport,$parking,$pavement,$garden,$fenced,$water,$electricity,$pool,$ensuite,$description);
        mysqli_stmt_execute($prep);
        if ($prep){
            $forimg = mysqli_insert_id($conn);
            header("Location: addlistingmedia.php?id=".$forimg);
            exit();
        }
        else{
            echo "Failed to add property,<a href='addlisting.php'>Try Again</a>";
        }
}
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Real Home</title>
	<style type="text/css">
		@font-face{
		font-family: play;
		src: url(fonts/Play-Bold.ttf) format('truetype');
		}
		body{
			font-family: play;
			color: black;
		}
		p{
			width: 300px;
			text-align: center;
		}
	</style>
</head>
<body>

</body>
</html>
<?php
	session_start();
	include "connection.php";
	include "login.php";

	if (isset($_POST['changepp'])){
		$user_id = $_SESSION['user_id'];

		$imgname = $_FILES['pp']['name'];
		$tempname = $_FILES['pp']['tmp_name'];
		$userimgfolder = "./userimages/" . basename($imgname);

		$ins = "UPDATE users SET profileimg = ? WHERE user_id = ?";
		$prep = mysqli_prepare($conn,$ins);
		mysqli_stmt_bind_param($prep,"ss",$imgname,$user_id);
		$reso = mysqli_execute($prep);
		if ($reso){
			$move = move_uploaded_file($tempname, $userimgfolder);

			if ($move){
				echo "Upload successful";
				header("Location: profilepage.php");
				exit;
			}
			else{
				echo "Failed to change your proifle image, <a href='profilepage.php'>Try Again</a>";
			}
		}
	else{
		echo "Failed to perfom operation <a href='profilepage.php'>Try Again</a>";
	}
	}

?>
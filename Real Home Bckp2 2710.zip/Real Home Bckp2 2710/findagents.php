<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Real Home - Find Agents</title>
	<link rel="stylesheet" type="text/css" href="styles/findagentsstyle.css">
</head>
<body>
	<header class="top">
			<h1>Find Agents of a <i>Real Home</i></h1>
	</header>
	<nav class="bottom">
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="contactus.php">Contact Us</a></li>
			<li>
				<?php
					session_start();
					include 'connection.php';

					if (isset($_SESSION['user_id'])) {
						$user_id = $_SESSION['user_id'];
						echo "<a href='profilepage.php'>You</a>";
					}
					else{
						echo "<a href='loginpage.html'>Sign in</a>";
					}
				?>
			</li>
		</ul>
	</nav>
	<div class="select">
		<center>
		<form name="agentregion" method="POST">
		<select name="region" class="sel">
			<option>City</option>
			<option value="Mokopane">Mokopane</option>
			<option value="Polokwane">Polokwane</option>
			<option value="Pretoria">Pretoria</option>
		</select>
		<input type="submit" name="filter" value="Filter" class="sel" style="border-style: solid; width: auto;background: black;color: white;">
		</form><br><br>
		</center>
	</div><br>
	<div class="middle">
		<center>
		<ul><?php
				if (isset($_POST['filter'])){
					function region(){
						if (isset($_POST['region'])){
							$region = $_POST['region'];
							$fetchstmt = "SELECT * FROM users WHERE usertype = 'Agent' AND city = '$region'";
							return $fetchstmt;
						}	
						else{
							$fetchstmt = "SELECT * FROM users WHERE usertype = 'Agent'";
							return $fetchstmt;
						}
					}
					$prep = mysqli_prepare($conn, region());
					mysqli_stmt_execute($prep);
					$res = mysqli_stmt_get_result($prep);
					if (mysqli_num_rows($res) > 0){
						while ($row = mysqli_fetch_assoc($res)) {
							$name = $row["username"];
							$sname = $row["surname"];
							$agentemail = $row["email"];
							$city = $row["city"];
							$imagename = $row["profileimg"];

							if (empty($imagename)){
								$img = "images/avatar.jpg";
							}
							else{
								$img = "./userimages/" . basename($imagename);
							}
							echo "<li>
								<div class='agentcard'>
									<div class='img'>
										<img src='$img' width='100%'  height='100%'  alt='Agent Photo'>
									</div>
									<h3>$name $sname</h3>
									<p>Located in: $city</p>
									<a href=\"contactagent.php?agentemail=" . urlencode($agentemail) . "\" class='contact'>Contact</a>
								</div>
								</li>";

						}
					}
					else{
						echo "No Agents in this region";
					}
				}
				else{
					echo "Set City to find agents";
				}
			?>
			
		</ul>
		</center>
	</div>
</body>
</html>
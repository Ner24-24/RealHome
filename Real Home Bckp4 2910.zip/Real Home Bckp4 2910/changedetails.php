<?php
	session_start();

	include 'connection.php';	
	include 'login.php';

	$user_id = $_SESSION['user_id'];

	function changeEmail($conn, $user_id){

		$newmail = $_POST['email'];

		$updatemail = "UPDATE users SET email = ? WHERE user_id = ?";
		$prep = mysqli_prepare($conn,$updatemail);
		mysqli_stmt_bind_param($prep,"ss",$newmail,$user_id);
		$execupdate = mysqli_stmt_execute($prep);

		if ($execupdate){
			echo "Email change successful";
			header("Location: profilepage.php");
		}
		else{
			echo "Failed to update email, <a href='profilepage.php'>Try Again</a>";
		}
	}

	function changeCellNo($conn, $user_id){
		
		$newcellno = $_POST['cellno'];

		$updatecellno = "UPDATE users SET cellno = ? WHERE user_id = ?";
		$prep = mysqli_prepare($conn,$updatecellno);
		mysqli_stmt_bind_param($prep,"ss",$newcellno,$user_id);
		$execupdate = mysqli_stmt_execute($prep);

		if ($execupdate){
			echo "Cell phone number updated successfully";
			header("Location: profilepage.php");
		}
		else{
			echo "Failed to update cell phone number, <a href='profilepage.php'>Try Again</a>";
		}
	}
	
	if (isset($_POST['changeem'])){
		changeEmail($conn, $user_id);
	}
	if (isset($_POST['changecellno'])){
		changeCellNo($conn, $user_id);
	}

?>
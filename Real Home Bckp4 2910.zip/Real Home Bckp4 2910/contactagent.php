<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="styles/contactusstyle.css?v=1.0">
	<title>Real Home</title>
	<style type="text/css">
		label{
			font-size: 20px;
		}
		a{
			cursor: pointer;
		}
	</style>
</head>
<body>

	<center>
		<?php
			session_start();
			include "connection.php";

			function isLoggedInemail(){
				
				if (isset($_SESSION["user_id"])){
					$user_id = $_SESSION["user_id"];
					$useremail = $_SESSION["email"];
					return $useremail;
					
				}
				else{
					return "";
				}
			}
			function isLoggedInname(){

				if (isset($_SESSION["user_id"])){
					$username = $_SESSION['username'];
					return $username;
				}
				else{
					return "";
				}
			}
			function isLoggedInCell(){

				if (isset($_SESSION["user_id"])){
					$usercell = $_SESSION['cellno'];
					return $usercell;
				}
				else{
					return "";
				}
			}
		?>
		<div class="signin">
			<center>
			<h1>Contact Us</h1><hr><br>
			<form action="phpmailer/emailagent.php" name="contact" method="POST">
			<input type="hidden" name="agentem" value="<?php echo $_GET['agentemail']; ?>">
			<label>Your name</label><br>
			<input type="text" name="fname" placeholder="Name" 
				value="<?php echo isLoggedinname(); ?>" required><br>
			<label>Your Email</label><br>
			<input type="Email" name="email" id="email" placeholder="Email" value="<?php echo isLoggedInemail(); ?>" required><br>
			<label>Cellphone Number</label><br>
			<input type="tel" name="cell" id="cell" placeholder="Cellphone Number" value="<?php echo isLoggedInCell(); ?>" required><br>
			<label>Subject</label><br>
			<input type="text" name="subject" id="subject" value="Estate Agent Needed" required><br><br>
			<!-- <label>Message</label><br> -->
			<textarea name="message" class="mess" required>Hello there, I am in need of your services.</textarea>
			<input type="submit" name="send" id="submit" value="Send" class="submit">
			</form>
			<a onclick="back()"><</a>
			</center>
		</div>
	</center>
	<script type="text/javascript">
		let backBtn = document.getElementByTagName("a");

		function back() {
		 	history.back()
		 } 
	</script>
</body>
</html>
let proptype = document.querySelector("#proptype");
let commercial = document.querySelectorAll("#bedrooms,#ensuitediv,#diningdiv");
let plot = document.querySelectorAll("#bedrooms,#bathrooms,#stories,#garages,#furnisheddiv,#kitchendiv,#loungediv,#balconydiv,#carportdiv,#parkingdiv,#pavementdiv,#gardendiv,#pooldiv,#diningdiv,#ensuitediv,#pavementdiv");

proptype.addEventListener("input",show);

function show() {

if (proptype.value === "commercial"){
	commercial.forEach(function (element) {
		element.style.display = "none";
		element.removeAttribute('required');
	});
	}

else if (proptype.value === "plot"){
	plot.forEach(function (element) {
		element.style.display = "none";
		element.removeAttribute('required');
	});
	}


else{
	commercial.forEach(function (element) {
		element.style.display = "block";
		element.setAttribute('required','true');
	});
	plot.forEach(function (element) {
		element.style.display = "block";
		element.setAttribute('required','true');
	});
	}
}
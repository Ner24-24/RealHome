<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Real Home</title>
	<link rel="stylesheet" type="text/css" href="styles/addlistingmedia.css?v=1.0">
	<script type="text/javascript">
		//for image name
	</script>
</head>
<body>
	<header>
		<h1>Real Home</h1>
		<nav >
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="contactus.php">Contact</a></li>
				<li>
					<?php
						session_start();
						include "connection.php";
						if (isset($_SESSION["user_id"])){
							echo "<a href='profilepage.php'>You</a>";
						}
						else{
							header("Location: loginpage.html");
						}
					?>
				</li>
			</ul>
		</nav>
	</header><br>

	<center>
		<?php

		if (isset($_GET['id'])){
			$prop_id = $_GET['id'];

			if (isset($_POST['upload'])){
				$imgname = $_FILES['imagename']['name'];
				$temp = $_FILES['imagename']['tmp_name'];
				$folder = "./propimages/". basename($imgname);

				$stmt = "INSERT INTO images(prop_id,filename) VALUES(?,?)";
				$prep = mysqli_prepare($conn, $stmt);
				mysqli_stmt_bind_param($prep,"is",$prop_id,$imgname);
				mysqli_stmt_execute($prep);
				move_uploaded_file($temp, $folder);
			}

			if (isset($_POST['delete'])){
				// Delete a record
				$filetodel = $_POST['filename'];
				$delstmt = "DELETE FROM images WHERE filename = ?";
				$prepdel = mysqli_prepare($conn, $delstmt);
				mysqli_stmt_bind_param($prepdel,"s", $filetodel);
				mysqli_stmt_execute($prepdel);
				$delim = "./propimages/" . basename($filetodel);
				// Delete from folder
				unlink($delim);
			}
			
		}
		if (isset($_POST['done'])){
				echo "Property Uploaded!, <a href='index.php'>Home</a>";
			}
	?>
	<form enctype="multipart/form-data" name="enterpropimages" method="POST">
		<div class="mediaupload">
			<h1>Upload Media</h1>
			<p>Upload Images of the property</p><br>
			<label for="uploadmedia" id="uploadlabel">
				<input type="file" name="imagename" id="uploadmedia" accept=".png, .jpg, .jpeg" multiple required style="display: none;">Select Image
			</label><br><br>
			<input type="submit" name="upload" class="submit" value="Upload Image"><hr>
			<input type="submit" name="done" class="submit" value="Done"><br>
		</div>
	</form>
	</center>
	<div class="mediapreview">
		<center>
		<h2>Preview Images</h2>
		<ul>
		<?php
			$dispstmt = "SELECT * FROM images WHERE prop_id = ?";
			$prepdisp = mysqli_prepare($conn,$dispstmt);
			mysqli_stmt_bind_param($prepdisp,"i",$prop_id);
			mysqli_stmt_execute($prepdisp);
			$execdisp = mysqli_stmt_get_result($prepdisp);

			if (mysqli_num_rows($execdisp) > 0){

				while ($fetch = mysqli_fetch_assoc($execdisp)){
				//$imgid = $fetch["image_id"];
				$file = $fetch["filename"];
				$image = "./propimages/" . basename($file);
				echo "<li>
						<div class='previm'>
							<img src='$image' width='100%' 
							height='100%'  alt='$file'>
							<p>$file</p>
							<form name='delete' method='POST'>
								<input type='hidden' name='filename' value='$file'>
								<input type='submit' name='delete' class='delete' value='Delete'>
							</form>
						</div></a>
					  </li>";
			}
			}


		?>
		</ul>
	</center>
	</div>
</body>
</html>
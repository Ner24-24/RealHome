<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="styles/newpassstyle.css">
	<title>Real Home - Reset Password</title>
</head>
<body>

	<center>
		<div class="signin">
			<center>
			<h1>Reset Password</h1><hr><br>
			<form action="changepass.php" id="login" name="login" method="POST">
				<input type="hidden" name="token" value="<?php echo $_GET['token']; ?>">
				<label>New Password</label>
				<input type="Password" name="newpass" placeholder="New Password Goes Here..." required><br><br>
				<label>Verify New password</label>
				<input type="Password" name="vernewpass" placeholder="Verify New Password" required><br><br>
				<input type="submit" name="resetpass" id="submit" value="Send email" class="submit">
			</form>
			<a href="index.php" class="home"><</a>
			</center>
		</div>
	</center>
</body>

</html>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Real Home-Add Listing</title>
	 <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
     integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY="
     crossorigin=""/>
 	<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
     integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo="
     crossorigin=""></script>
     <!-- External Style and Script -->
     <link rel="stylesheet" type="text/css" href="styles/addlistingstyle.css?v=1.0">
     <script type="text/javascript" src="scripts/addlisting.js"></script>

</head>
<body>

	<header class="top">
		<h1>Real Home</h1>
		<nav class="bottom">
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="contactus.php">Contact</a></li>
				<li>
					<?php
						session_start();
						include "connection.php";
						if (isset($_SESSION["user_id"])){
							$user_id = $_SESSION['user_id'];
							echo "<a href='profilepage.php'>You</a>";
						}
						else{
							header("Location: loginpage.html");
						}
					?>
				</li>
			</ul>
		</nav><br><br><br>
	</header>

	<div class="middle">
		<div class="ent" id="entdet">
			<center>
				<!-- <a href="addlistingmedia.php">Addlistingmedia</a> -->
				<h2>Enter Property Details</h2>
				<p style="opacity: 50%;">* Means the input field is compulsory</p>
				<p>Please select option once*</p>
			<form action="addlistingdetails.php" name="enterpropdetails" method="POST">
				<select name="proptype" id="proptype" required>
					<option>Property type</option>
					<option value="Aparment" id="aparment">Apartment</option>
					<option value="House" id="house">House</option>
					<option value="Commercial" id="commercial">Commercial</option>
					<option value="Plot" id="plot">Plot</option>
					<option value="Cottage" id="cottage">Cottage</option>
					<!--Include PHP code for all types from database on testing-->
				</select>
				<select name="listingtype">
					<option value="Sell">Sell</option>
					<option value="Lease">Lease</option>
				</select><br>
				<label for="date">*Listing Date<br><input type="Date" name="date" id="date" value="Today"></label><br>
				
				<label for="propname">*Property Name<br><input type="text" name="propname" id="propname" placeholder="Eg. 2 bed house in Mokopane"></label><br>
				
				<label for="propaddress">Property Address<br><input type="text" name="propaddress" id="propaddress" placeholder="Eg. 23 John Doe Street CityName"></label><br>

				<label for="province">*Province<br><input type="text" name="province" id="province" placeholder="Eg. Gauteng" required></label><br>

				<label for="city">*City/Town<br><input type="text" name="city" id="city" placeholder="Eg. Pretoria" required></label><br>

				<p>Plot the location of the Property<br>DOUBLE TAP and HOLD to move around the map</p>
				<button type="button" class="submit" id="plotloc">Plot Location</button><br>
				<input type="text" name="coords" id="plotlocval" class="submit"><br>
				<label for="suburb">*Suburb</label><br>
				<input type="text" name="suburb" id="suburb" placeholder="Enter the suburb here" required>

				<p style="opacity: 50%;">**Do not  include any CURRENCY or  UNIT**</p>
				<ul class="primary">
					<li><label id="stories">*Number of Bedrooms</label>
					<input type="Number" name="bedrooms" id="bedrooms" class="bedrooms" placeholder="Bedrooms" min="1" required></li><br>

					<li><label id="stories">*Number of Bathrooms</label>
					<input type="Number" name="bathrooms" id="bathrooms" placeholder="Bathrooms" min="1" required></li><br>

					<li><label id="stories">*Number of Garages</label>
					<input type="Number" name="garages" id="garages" placeholder="Garages" min="1"></li><br>

					<li id="stories"><label>**Number of Stories</label>
					<input type="Number" name="stories" id="stories" placeholder="Stories" min="1"></li><br>

					<li><label>*Price</label><br>
					<input type="Number" name="propprice" id="propprice" placeholder="Enter Price" min="1" required></li><br>

					<li><label>*Area in Square Meters</label>
					<input type="Number" name="area" id="area" placeholder="Enter Area" min="1"></li><br>
				</ul>
				<label for="description">*Description<br><textarea name="description" placeholder="Describe the Property" rows="10px" id="description" required></textarea></label><br>

				<div class="tick">
					<div id="furnisheddiv">
					<input type="checkbox" name="furnished" value="Yes" id="furnished" class="check"><label>Furnished</label>
					</div>

					<div id="kitchendiv">
					<input type="checkbox" name="kitchen" value="Yes" id="kitchen" class="check"><label>Kitchen</label>
					</div>

					<div id="loungediv">
					<input type="checkbox" name="lounge" value="Yes" id="lounge" class="check"><label>Lounge</label>
					</div>

					<div id="diningdiv">
					<input type="checkbox" name="dining" value="Yes" id="dining" class="check"><label>Dining Area</label>
					</div>

					<div id="balconydiv">
					<input type="checkbox" name="balcony" value="Yes" id="balcony" class="check"><label>Balcony</label>
					</div>

					<div id="carportdiv">
					<input type="checkbox" name="carport" value="Yes" id="carport" class="check"><label>Car Port</label>
					</div>

					<div id="parkingdiv">
					<input type="checkbox" name="parking" value="Yes" id="carport" class="check"><label>Parking</label>
					</div>

					<div id="pavediv">
					<input type="checkbox" name="paved" value="Yes" id="paved" class="check"><label>Pavement</label>
					</div>

					<div id="gardendiv">
					<input type="checkbox" name="garden" value="Yes" id="paved" class="check"><label>Garden</label>
					</div>

					<div id="fencediv">
					<input type="checkbox" name="fenced" value="Yes" id="fenced" class="check"><label>Fenced</label>
					</div>

					<div id="waterdiv">
					<input type="checkbox" name="water" value="Yes" id="water" class="check"><label>Water</label>
					</div>

					<div id="electricitydiv">
					<input type="checkbox" name="electricity" value="Yes" id="electricity" class="check"><label>Electricity</label>
					</div>

					<div id="pooldiv">
					<input type="checkbox" name="pool" value="Yes" id="swpool" class="check"><label>Pool</label>
					</div><br><br>

					<div id="ensuitediv">
					<input type="checkbox" name="ensuite" value="Yes" id="ensuite" class="check"><label>En-suite</label>
					</div><hr>
					<input type="hidden" name="listerid" value="<?php echo $user_id?>">
				</div>
				<input type="submit" name="submit" class="submit" value="Submit">
			</form>
			</center>
		</div>

<div id="mapcont">
	<div class="map" id="map">
	</div>
	<button id="back">X</button>
</div>

<!-- Map Script -->
<script type="text/javascript">
	let coOrds = document.getElementById("plotloc");
	let mapDiv = document.getElementById("mapcont");
	let backBtn = document.getElementById("back");
	let body = document.querySelectorAll(".top, .middle, .bottom");
	
	let map = L.map('map').setView([-27.567556, 25.567576], 6);
	L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
	}).addTo(map);
	coOrds.addEventListener("click",showMap);
	backBtn.addEventListener("click",closeMap);

	function showMap() {
		if (mapDiv.style.visibility === "hidden"){
			mapDiv.style.visibility = "visible";
			body.forEach(function (section) {
				section.style.visibility = "hidden";
			});
		}
		else{
			mapDiv.style.visibility = "hidden";
			body.forEach(function (section) {
			section.style.visibility = "visible";
			});
		}

	}
	function closeMap() {
		if (mapDiv.style.visibility === "visible"){
			mapDiv.style.visibility = "hidden";
			body.forEach(function (section) {
				section.style.visibility = "visible";
			});
		}
		else{
			mapDiv.style.visibility = "visible";
			body.forEach(function (section) {
				section.style.visibility = "hidden";
			});
		}
	}


	let loc = L.popup();
	let out = document.getElementById("plotlocval");
	function getCoords(e) {
	    loc
	        .setLatLng(e.latlng)
	        .setContent("Location is " + e.latlng.toString())
	        .openOn(map);
	        let latit = e.latlng.lat;
	        let longit = e.latlng.lng;
	        out.value = `${latit.toFixed(6)},${longit.toFixed(6)}`;
	}

	map.on('click', getCoords);
</script>
</body>
</html>
<?php
	
	include 'connection.php';

	if (isset($_POST["resetpass"])){

		$token = $_POST["token"];
		$newpass = $_POST['newpass'];
		$vernewpass = $_POST['vernewpass'];

		if ($newpass == $vernewpass){

			$check = "SELECT * FROM password_resets WHERE token = ? AND expire_at > NOW()";

			$prep = mysqli_prepare($conn, $check);
			mysqli_stmt_bind_param($prep,"s", $token);
			$execcheck = mysqli_stmt_execute($prep);
			$res = mysqli_stmt_get_result($prep);

			if (mysqli_num_rows($res) > 0){
				$fetch = mysqli_fetch_assoc($res);
				$user_id = $fetch["used_id"];
				$newhashedpass = password_hash($newpass, PASSWORD_DEFAULT);

				$updatepass = "UPDATE users SET pass = ? WHERE user_id = ?";
				$prep = mysqli_prepare($conn, $updatepass);
				mysqli_stmt_bind_param($prep,"si", $newhashedpass, $user_id);
				$execupdate = mysqli_stmt_execute($updatepass);

				if ($execupdate){
					echo "Password has been reset successfully, <a href='loginpage.html'>Login</a>";
				}
				else{
					echo "Failed to reset password as user might not exist, <a href='resetpass.php'>Try again</a>";
				}
			}
			else{
				echo "Reset Password session has EXPIRED, Reset again <a href='forgotp.html'>HERE</a>";
			}
		}
		else{
			echo "Passwords do not match, <a href='resetpass.php'>Try again</a>";
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Real Home</title>
	<style type="text/css">
		*{
			font-weight: bold;
		}
		body{
			justify-content: center;
			align-items: center;
			display: flex;
		}
		p{
			font-family: sans-serif;
			font-size: 200px;
		}
		a{
			color: black;
		}
	</style>
</head>
<body>

</body>
</html>
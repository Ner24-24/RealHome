<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Real Home</title>
	<link rel="stylesheet" type="text/css" href="styles/profilepagestyle.css">
</head>
<body>
	<div class="top">
		<h1>Real Home</h1>
		<nav class="bottom">
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="contactus.php">Contact Us</a></li>
				<li><a href="findagents.php">Find Agents</a></li>
			</ul>
		</nav>
	</div>

	<div class="middle">
		<?php
			session_start();
			include "connection.php";
			if(isset($_SESSION['user_id'])){
				$user_id = $_SESSION['user_id'];
			}
			else{
				header("Location: loginpage.html");
			}
		?>
		<?php
			$fetchstmt = "SELECT * FROM users WHERE user_id = ?";
			$prep = mysqli_prepare($conn,$fetchstmt);
			mysqli_stmt_bind_param($prep,"s", $user_id);
			mysqli_stmt_execute($prep);
			$res = mysqli_stmt_get_result($prep);

			if (mysqli_num_rows($res) > 0){
				$fetch = mysqli_fetch_assoc($res);
				$name = $fetch["username"];
				$useremail = $fetch["email"];
				$cell = $fetch["cellno"];
				$imgname = $fetch["profileimg"];
				$img = "./userimages/" . $imgname;
			}

			function displayImage($imgname,$img){
				if (empty($imgname)){
					return "images/avatar.jpg";
				}
				else{
					return "$img";
				}
			}
		?>
		<div>
			<center>
			<div class="img">
				<img src="<?php echo displayImage($imgname,$img)?>" alt="You" width="100%" height="100%">
			</div>
			<p id="name">
				<?php
					echo "Welcome $name";
					$lstnumstmt = "SELECT COUNT(prop_id) FROM properties WHERE user_id = $user_id";
					$execnum = mysqli_query($conn, $lstnumstmt);
					$nums = mysqli_fetch_array($execnum);
				?>
			</p>
			<p id="listings"><?php echo "Listings: $nums[0]"; ?></p>
			<p id="email">Email: <?php echo "$useremail"; ?></p>
			<p id="cellnums">Phone Number: <?php echo "$cell"; ?></p>
			<p id="agency">Agency: None</p>
			<button><a href="addlisting.php">Add a listing</a></button><br>
			<h2>Change Details</h2><hr class="ch">
			<form name="changepp" action="changepicture.php" enctype="multipart/form-data" method="POST">
				<label for="pp" class="changelab">
					Click Here to Change Profile Picture
					<input type="file" name="pp" id="pp" placeholder="New Email" style="visibility: hidden;" accept=".png,.jpg,.jpeg" required>
				</label><br>
				<button type="submit" name="changepp" class="change">Change</button><br>
			</form><br>
			<!-- Change details form -->
			<form name="changedet" action="changedetails.php" method="POST">
				<input type="email" name="email" placeholder="New Email">
				<button type="submit" name="changeem" class="change">Change</button><br>
				<input type="tel" name="cellno" placeholder="New Phone Number" pattern="[0-9]{3}[0-9]{3}[0-9]{4}">
				<button type="submit" name="changecellno" class="change">Change</button><br>
				<input type="text" name="agency" placeholder="Change Agency">
				<button type="submit" name="changeag" class="change">Change</button><br><br><br>
			</form>
			<form name="logoutform" action="logout.php" method="POST">
				<button type="submit" name="logout" class="change">Log Out</button>
			</form>
			</center>
		</div>
			<center>
			<h2>Favorites:</h2><hr>
			</center>
			<?php

			?>
			<div class="favorites">
				<ul>
				<?php
					$favstmt = "SELECT * FROM favorites WHERE user_id = ?";
					$favprep = mysqli_prepare($conn, $favstmt);
					mysqli_stmt_bind_param($favprep,"i", $user_id);
					mysqli_stmt_execute($favprep);
					$favres = mysqli_stmt_get_result($favprep);

					if (mysqli_num_rows($favres) > 0){
						$fetchprop = mysqli_fetch_assoc($favres);
						$favpropid = $fetchprop["prop_id"];
						$favpropstmt = "SELECT * FROM properties WHERE prop_id = ?";
						$favpropprep = mysqli_prepare($conn, $favpropstmt);
						mysqli_stmt_bind_param($favpropprep,"i", $favpropid);
						mysqli_stmt_execute($favpropprep);
						$favpropres = mysqli_stmt_get_result($favpropprep);
						while ($favfetch = mysqli_fetch_assoc($favpropres)){
						$favpropname = $favfetch["name"];
						$favproptype = $favfetch["proptype"];
						$favpropprice = $favfetch["price"];
						
						$favpropimgstmt = "SELECT filename FROM images WHERE prop_id = ?";
						$favimgprep = mysqli_prepare($conn, $favpropimgstmt);
						mysqli_stmt_bind_param($favimgprep,"i", $favpropid);
						mysqli_stmt_execute($favimgprep);
						$favimgres = mysqli_stmt_get_result($favimgprep);
						if (mysqli_num_rows($favimgres) > 0){
							$favimgfetch = mysqli_fetch_assoc($favimgres);
							$favimg = $favimgfetch["filename"];
							$favimgpath = "./propimages/" . basename($favimg);
							echo "<li>
								<center>
								<div class='propbox'>
								<img src='$favimgpath' width='100%' 
								height='100%'  alt='$favimg'>
								<h3>$favpropname</h3>
								<p>$favproptype</p>
								<p>R$favpropprice</p>
								<form>
									<input type='submit' name='delete' value='Delete' class='status'>
								</form>
								<a href=\"property.php?propid=" . 
								urlencode($favpropid) . "\" class='status'>View</a>
								</div>
								</center>
							</li>";
						}
						}
					}
					else{
						echo "
						<center>
						No favorite Properties
						</center>";
					}
				?>
				</ul>
			</div>

			<center>
			<h2>Your Listings: <!--Number from database--></h2><hr>
			</center>
			<div class="favorites">
				<ul>
				<?php
					$lststmt = "SELECT * FROM properties WHERE user_id = ?";
					$lstprep = mysqli_prepare($conn,$lststmt);
					mysqli_stmt_bind_param($lstprep,"i", $user_id);
					mysqli_stmt_execute($lstprep);
					$lstres = mysqli_stmt_get_result($lstprep);

					if (mysqli_num_rows($lstres) > 0){
					
						while ($lstfetch = mysqli_fetch_assoc($lstres)){
						$propid = $lstfetch["prop_id"];
						$propname = $lstfetch["name"];
						$propprice = $lstfetch["price"];
						$proptype = $lstfetch["proptype"];
						
						$lstimgstmt = "SELECT filename FROM images WHERE prop_id = ?";
						$lstimgprep = mysqli_prepare($conn, $lstimgstmt);
						mysqli_stmt_bind_param($lstimgprep,"i", $propid);
						mysqli_stmt_execute($lstimgprep);
						$lstimgres = mysqli_stmt_get_result($lstimgprep);
						if (mysqli_num_rows($lstimgres) > 0){
							$lstimgfetch = mysqli_fetch_assoc($lstimgres);
							$lstimg = $lstimgfetch["filename"];
							$lstimgpath = "./propimages/" . basename($lstimg);
							echo "<li>
								<center>
								<div class='propbox'>
								<img src='$lstimgpath' width='100%' 
								height='100%'  alt='$lstimg'>
								<h3>$propname</h3>
								<p>R$propprice</p>
								<form method='POST'>
									<input type='submit' name='delete' value='Delete' class='status'>
								</form>
								<a href='property.php?id=$propid' class='submit'>View</a>
								</div>
								</center>
							</li>";
						}
						}
					}
					else{
						echo "You have no listings";
					}
				?>
				</ul>
			</div>
	</div>
	<?php
		if (isset($_POST['delete'])){
			$delstmt = "DELETE FROM properties WHERE prop_id = ?";
			$delprep = mysqli_prepare($conn, $delstmt);
			mysqli_stmt_bind_param($delprep,"i", $propid);
			mysqli_stmt_execute($delprep);

			$delimgstmt = "DELETE FROM images WHERE prop_id = ?";
			$delimgprep = mysqli_prepare($conn, $delimgstmt);
			mysqli_stmt_bind_param($delimgprep,"i", $propid);
			mysqli_stmt_execute($delprep);
			$delimfolder = "./propimages/" . basename($file);
			unlink($delimfolder);
		}
	?>
</body>
</html>
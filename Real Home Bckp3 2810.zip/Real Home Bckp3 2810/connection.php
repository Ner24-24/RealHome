<?php

	$server = "localhost";
	$admin = "root";
	$pass = "";
	$db = "realhome";

	$conn = new mysqli($server,$admin,$pass,$db);

	if (!$conn){
		die("Failed to connect to the DataBase".mysql_connect_error());
	}
?>
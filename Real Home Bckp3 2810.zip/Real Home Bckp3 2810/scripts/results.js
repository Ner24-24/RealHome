
let filterBtn = document.getElementById("filter");
let backBtn = document.getElementById("back");
let topDiv = document.getElementById("top");
let middleDiv = document.getElementById("middle");
let bottomDiv = document.querySelector('.bottom');
let filterBox = document.getElementById("filterbox");


filterBtn.addEventListener("click", displayFilterBox)
function displayFilterBox() {
	if (filterBox.style.visibility === "hidden"){
		topDiv.style.visibility = "hidden";
		middleDiv.style.visibility = "hidden";
		bottomDiv.style.visibility = "hidden";
		filterBox.style.visibility = "visible";
		filterBox.style.animation = "intro 1s";

	}
	else{
		topDiv.style.visibility = "visible";
		middleDiv.style.visibility = "visible";
		bottomDiv.style.visibility = "visible";
		filterBox.style.visibility = "hidden";
		filterBox.style.animation = "idle";
	}
}

backBtn.addEventListener("click", backToResults)
function backToResults() {
	if (filterBox.style.visibility === "visible"){	
	topDiv.style.visibility = "visible";
	middleDiv.style.visibility = "visible";
	bottomDiv.style.visibility = "visible";
	filterBox.style.visibility = "hidden";
	filterBox.style.animation = "idle";
	}
	else{
	topDiv.style.visibility = "hidden";
	middleDiv.style.visibility = "hidden";
	bottomDiv.style.visibility = "hidden";
	filterBox.style.visibility = "visible";
	filterBox.style.animation = "intro 1s";
	}
}
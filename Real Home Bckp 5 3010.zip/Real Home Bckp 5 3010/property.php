<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Real Home</title>
	<link rel="stylesheet" type="text/css" href="styles/propertystyle.css?v=1.0">
	
	<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
     integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY="
     crossorigin=""/>
     <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
     integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo="
     crossorigin=""></script>
     <style type="text/css">
     	.up{
     		padding: 10px;
     		text-decoration: none;
     		position: fixed;
     		right: 2%;
     		top: 60%;
     		font-size: 40px;
     		background: black;
     		border-radius: 50%;
     		color: white;
     		display: flex;
     		align-items: center;
     		justify-content: center;
     		cursor: pointer;
     	}
     </style>
</head>
<body>
	<header class="top">
		<h1>Real Home</h1>
		<nav class="bottom">
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="contactus.php">Contact Us</a></li>
				<li>
					<?php
						session_start();
						include "connection.php";
						if (isset($_SESSION['user_id'])){
							$user_id = $_SESSION['user_id'];
							echo "<a href='profilepage.php'>You</a>";
						}
						else{
							echo "<a href='loginpage.html'>Sign in</a>";
						}
					?>
				</li>
			</ul>
		</nav>

	</header><br><br>

	<div class="middle">

		<p class="backtores"><--Back</p><br>
		<?php 
			$propid = $_GET['propid'];

			$stmt = "SELECT * FROM properties WHERE prop_id = ?";
			$prep = mysqli_prepare($conn, $stmt);
			mysqli_stmt_bind_param($prep,"s", $propid);
			mysqli_stmt_execute($prep);
			$res = mysqli_stmt_get_result($prep);
			$fetch = mysqli_fetch_assoc($res);
			$listerid = $fetch["user_id"];
			$propname = $fetch["name"];
			$date = $fetch["listingdate"];
			$propprice = $fetch["price"];
			$address = $fetch["address"];
			$location = $fetch["location"];
			$suburb = $fetch["suburb"];
			$beds = $fetch["bedrooms"];
			$baths = $fetch["bathrooms"];
			$furnished = $fetch["furnished"];
			$kitchen = $fetch["kitchen"];
			$lounge = $fetch["lounge"];
			$dining = $fetch["diningarea"];
			$garages = $fetch["garages"];
			$stories = $fetch["stories"];
			$balcony = $fetch["balcony"];		
			$carport = $fetch["carport"];
			$fenced = $fetch["fenced"];
			$pavement = $fetch["pavement"];
			$garden = $fetch["garden"];
			$pool = $fetch["pool"];
			$ensuite = $fetch["ensuite"];
			$water = $fetch["water"];
			$electricity = $fetch["electricity"];
			$description = $fetch["description"];
			
			function isMap($location,$address){
				if (empty($location)){
					$location = "<p>$address</p>";
					return $location;
				}

				else{
					$location = "<p id='location'>$address</p>";
					return $location;
				}
				if(empty($address)){
					return "<a href='#agent'>Contact Agent for address</a>";
				}
			}
			function isAvail($date){
				$today = date("Y-m-d");
				if (strtotime($today) > strtotime($date)){
					return "<p id='status'>Available</p>";
				}
				else{
					return "<p id='status'>Avail $date</p>";
				}
			}
		?>
		<div class="propbox">
			<section>
				<nav>
					<ul>
						<?php
							$imgstmt = "SELECT * FROM images where prop_id = ?";
							$imgprep = mysqli_prepare($conn, $imgstmt);
							mysqli_stmt_bind_param($imgprep,"s", $propid);
							mysqli_stmt_execute($imgprep);
							$imgres = mysqli_stmt_get_result($imgprep);
							$count = 0;
							while($fetchimgs = mysqli_fetch_assoc($imgres)){
								$count++;
								$imgs = $fetchimgs["filename"];
								$img = "./propimages/" . basename($imgs);

								echo "<li><img src='$img' width='200' height='200' class='image'></li><br>";
								if ($count == 1){
									echo "<br><center><a href='#tofloat' class='viewdet'>Click here to view the Details</a></center><br>";
								} 
							}
						?>
					</ul>
				</nav>
			</section><br>
			<p id="tofloat"><?php echo $propname; ?></p>
			<?php echo isAvail($date); ?>
			<p id="tofloat">R<?php echo $propprice; ?></p>
			<?php echo isMap($location,$address); ?>
			<?php
	
				function checkFavorites($conn,$user_id,$propid) {
				    
				    if (isset($user_id)) {
				        // Use prepared statements to prevent SQL injection
				        $checkfavstmt = "SELECT * FROM favorites WHERE user_id = ? AND prop_id = ?";
				        $checkfavprep = mysqli_prepare($conn, $checkfavstmt);
				        mysqli_stmt_bind_param($checkfavprep, "ii", $user_id, $propid);
				        mysqli_stmt_execute($checkfavprep);
				        $result = mysqli_stmt_get_result($checkfavprep);

				        if (mysqli_num_rows($result) > 0) {
				            return "<p style='background-color: red; width: 10%;text-align: center; border-radius: 5px;'>Favorite</p>";
				            exit();
				        }
				    }
				    else{
				    	header("Location: loginpage.html");
				    }
				}

				function favorites($conn,$propid) {
					$user_id = $_SESSION['user_id'];

				    if (isset($_POST['addtofav'])){
				    	// Prepare statement for inserting into favorites
				        $addstmt = "INSERT INTO favorites(user_id, prop_id) VALUES(?, ?)";
				        $addprep = mysqli_prepare($conn, $addstmt);
				        mysqli_stmt_bind_param($addprep, "ii", $user_id, $propid);
				        mysqli_stmt_execute($addprep);
				        
				        if (mysqli_stmt_execute($addprep)) {
				            return "<p>Favorite</p>";
				            exit();
						}
					}
				}
			        					
			?>
			<?php
				if (isset($_SESSION["user_id"])){
					$user_id = $_SESSION['user_id'];
					echo checkFavorites($conn,$user_id,$propid);
					echo favorites($conn,$propid);
				}
				else{
					echo "<form name='addtofavorites' method='POST'>
			                <input type='hidden' name='prop_id' value='<?php echo $propid; ?>'>
			                <input type='submit' name='addtofav' value='Add to Favorites' class='addfav'>
			            </form><br>";
					if (isset($_POST["addtofav"])){
						header("Location: loginpage.html");
					}
				}
			?>
			<form name='addtofavorites' method='POST'>
                <input type='hidden' name='prop_id' value='<?php echo $propid; ?>'>
                <input type='submit' name='addtofav' value='Add to Favorites' class='addfav'>
            </form><br>
			<ul class="details">
				<li>Bedrooms: <?php echo $beds; ?></li>
				<li>Bathrooms: <?php echo $baths; ?></li>
				<li>Garage: <?php echo $garages; ?></li>
				<li>Stories: <?php echo $stories; ?></li>
				<li>Furnished: <?php echo $furnished; ?></li>
				<li>Kitchen: <?php echo $kitchen; ?></li>
				<li>Car Port: <?php echo $carport; ?></li>
				<li>Fenced: <?php echo $fenced; ?></li>
				<li>Garden: <?php echo $garden; ?></li>
				<li>Water: <?php echo $water; ?></li>
			</ul>
			<p>Description</p>
			<p class="desc" id="desc">
				<?php echo $description; ?>
			</p>
			<button class="showmore" id="showmore">+Show more</button><hr><br>
			<center>
				<?php
					$getlister = "SELECT * FROM users WHERE user_id = '$listerid'";
					$execlister = mysqli_query($conn, $getlister);
					$fetchdet = mysqli_fetch_assoc($execlister);
					$name = $fetchdet["username"];
					$sname = $fetchdet["surname"];
					$email = $fetchdet["email"];
					$imgname = $fetchdet["profileimg"];
					$img = "./userimages/" . basename($imgname);
					
					function isImage($img){
						if (empty($imgname)){
						$img = "images/avatar.jpg";
					}
						else{
							$img = $img;
						}
					}
					
				?>
				<p>Propery Lister</p>
				<a href="viewagent.php?agentid=<?php echo $listerid; ?>"><div class="agent">
					<div class="img"><img src="<?php echo isImage($img);?>" height="100%" width="100%"></div>
					<p><?php echo $name; echo " $sname"; ?></p>
					<a href="contactagent.php?agentemail=<?php echo $email; ?>" class="contact" id="agent" 
					>Contact</a>
				</div></a><br>
			</a>
			</center>
		</div>
	<a href="#top" class="up">UP</a>
	</div>
	<div class="mapcont" id="mapcont">
		<button class="mapbutton">X</button>
		<div id="map" class="map">
			
		</div>	
	</div>
</body>
<script type="text/javascript">
	let descBtn = document.getElementById('showmore');
	let desc = document.getElementById('desc');
	let backToRes = document.querySelector('.backtores');
	let favBtn = document.querySelector(".addfav");
	let steps = 0;
	favBtn.addEventListener("click",function () {
		history.replaceState();
		preventDefault();
	});
	
	backToRes.addEventListener("click", backToResults);
	function backToResults(steps) {
		history.back();
	}
	descBtn.addEventListener("click",showmore);
	function showmore() {
		if (desc.style.overflow === "hidden"){
			desc.style.height = "auto";
			desc.style.overflow = "visible";
			desc.style.animation = "showmore 1s";
			desc.style.opacity = "100%";
			descBtn.innerHTML = "-Show Less";
		}else{
			desc.style.height = "40px";
			desc.style.overflow = "hidden";
			desc.style.animation = "when";
			desc.style.opacity = "50%";
			descBtn.innerHTML = "+Show more";
		}
	}
</script>
<script type="text/javascript">
	let prop = document.querySelectorAll(".top, .middle, .bottom");
	let showloc = document.getElementById("location");
	let closeMapB = document.querySelector(".mapbutton");
	let mapDiv = document.getElementById("mapcont");
	showloc.addEventListener("click",openMap);
	closeMapB.addEventListener("click", closeMap);

	const coords = "<?php echo $location; ?>";
	const [lat,long] = coords.split(",");
	let lati = parseFloat(lat);
	let longi = parseFloat(long);
	let map = L.map('map').setView([lati, longi], 15);
	L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
	}).addTo(map);

	L.marker([lati,longi],15).addTo(map);

	function openMap() {
		if (mapDiv.style.visibility === "hidden"){
		mapDiv.style.visibility = "visible";
		prop.forEach(function (element) {
			element.style.visibility = "hidden";
		});
		}
		else{
			mapDiv.style.visibility = "hidden";
			prop.forEach(function (element) {
				element.style.visibility = "visible";
			});
	}
	}
	function closeMap(element) {
		if (mapDiv.style.visibility === "visible"){
			mapDiv.style.visibility = "hidden";
			prop.forEach(function (element) {
	    	element.style.visibility = "visible";
		});
		}
		else{
			mapDiv.style.visibility = "visible";
			prop.forEach(function (element) {
	    	element.style.visibility = "hidden";
		});
		}
	}
</script>
</html>
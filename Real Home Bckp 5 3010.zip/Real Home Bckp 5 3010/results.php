<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale= 1.0">
	<title>Real Home</title>
	<link rel="stylesheet" type="text/css" href="styles/resultsstyle.css?v=1.0">
	<script type="text/javascript" src="scripts/results.js" async defer></script>
</head>
<body>
	<header class="top" id="top">
	<h1>Real Home</h1>
	<nav class="bottom">
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="contactus.html">Contact Us</a></li>
			<li>
				<?php
					session_start();
					include 'connection.php';
					if (isset($_SESSION["user_id"])){
						$user_id = $_SESSION['user_id'];
						echo "<a href='profilepage.php'>You</a>";
					}
					else{
						echo "<a href='loginpage.html'>Sign In</a>";
					}
				?>
			</li>
		</ul>
	</nav>
	</header><br>
	<div class="middle" id="middle">
		<center>
			<?php $selectedtype = $_GET['listingtype']; ?>
			<form name="searchfor" action="results.php" method="GET">
				<select name="listingtype" id="rp" required class="sel">
		            <option value="Lease" <?php echo ($selectedtype == "Lease") ? "selected" : ""; ?>>Rent</option>
		            <option value="Sell" <?php echo ($selectedtype == "Sell") ? "selected" : ""; ?>>Purchase</option>
        		</select><br><br>
				<!-- <input type="hidden" name="listingtype" value="<?php //echo $_GET['listingtype']; ?>"> -->
				<input type="search" name="search" value="<?php echo $_GET["search"]; ?>" placeholder="Search for Properties"><br>
				<button type="submit" id="results" name="search">Search</button><br><br>
			</form>
			<button id="filter" class="filter" name="filter">Filter</button>
		</center>
		<?php
			$input = mysqli_real_escape_string($conn,$_GET["search"]);
			$listingtype = $_GET["listingtype"];
			$getprops = "%$input%";
			$stmt = "SELECT * FROM properties WHERE listingtype = '$listingtype' AND (name LIKE '$getprops' OR bedrooms LIKE '$getprops' OR suburb LIKE '$getprops')";
			$prep = mysqli_prepare($conn,$stmt);
			mysqli_stmt_execute($prep);
			$res = mysqli_stmt_get_result($prep);

			if (mysqli_num_rows($res) > 0){
			
				while ($fetch = mysqli_fetch_assoc($res)){
					$propid = $fetch["prop_id"];
					$lister = $fetch["user_id"];
					$propname = $fetch["name"];
					$propprice = $fetch["price"];
					$proptype = $fetch["proptype"];
					$beds = $fetch["bedrooms"];
					$baths = $fetch["bathrooms"];

					$lister = "SELECT * FROM users WHERE user_id = '$lister'";
					$execlister = mysqli_query($conn, $lister);
					$fetchlister = mysqli_fetch_assoc($execlister);
					$listername = $fetchlister["username"];
					$surname = $fetchlister["surname"];				
					$lstimgstmt = "SELECT filename FROM images WHERE prop_id = ?";
					$lstimgprep = mysqli_prepare($conn, $lstimgstmt);
					mysqli_stmt_bind_param($lstimgprep,"i", $propid);
					mysqli_stmt_execute($lstimgprep);
					$lstimgres = mysqli_stmt_get_result($lstimgprep);
					if (mysqli_num_rows($lstimgres) > 0){
						$imgfetch = mysqli_fetch_assoc($lstimgres);
						$img = $imgfetch["filename"];
						$imgpath = "./propimages/" . basename($img);

						echo "<a href=\"property.php?propid=" . urlencode($propid) . "\">
							<div class='prop'>
							<div class='img'>
								<img src='$imgpath'>
							</div>
							<div class='info'>
								<h3 id='pname'>$propname</h3>
								<p id='status'>$proptype</p>
								<p id='aname'>Listed By $listername $surname</p>
								<p id='price'>R$propprice</p>
								<p>Bedrooms: $beds</p>
								<p>Bathrooms: $baths</p>
							</div><br>
						</div></a><br>";
					}}
			}
			else{
				echo "
				<center>
					<p style='font-size: 30px;'>No Properties found</p>
				</center";
			}
		?>
		
	</div>
	
	<div class="filterbox" id="filterbox">
		<center>
		<button class="back" id="back">X</button>
		<h2>Refine Results</h2><hr><br>
		<form name="refine" action="filteredresults.php" method="GET">
			<select id="proptype" name="type" class="sel">
				<option>Property type</option>
				<option value="Apartment" id="aparment">Apartment</option>
				<option value="House" id="house">House</option>
				<option value="Commercial" id="commercial">Commercial</option>
				<option value="Plot" id="plot">Plot</option>
			</select>
			<input type="Number" name="price" placeholder="Max Price" class="sel">

			<div class="primary">
				<div>
					<label for="bedrooms">Bedrooms</label>
					<input type="Number" name="bedrooms" id="bedrooms" class="bedrooms"  min="0" max="99"><br>
				</div>

				<div>
					<label for="bathrooms">Bathrooms</label>
					<input type="Number" name="bathrooms" id="bathrooms"  min="0" max="99"><br>
				</div>

				<div>
					<label for="garages">Garages</label>
					<input type="Number" name="garages" id="garages"  min="0" max="99"><br>
				</div>

				<div>
					<label for="stories">Stories</label>
					<input type="Number" name="stories" id="stories"  min="0" max="99"><br>
				</div>
			</div>

			<h3>Amenities</h3><hr class="sub">

			<div class="amenities">
				<div>
				<input type="checkbox" name="pool" value="Yes" id="swpool" class="check"><label for="pool">Pool</label><br>
				</div>

				<div>
				<input type="checkbox" name="balcony" value="Yes" id="balcony" class="check"><label for="balcony">Balcony</label><br>
				</div>

				<div>
				<input type="checkbox" name="furnished" value="Yes" id="furnished" class="check"><label for="furnished">Furnished</label><br>
				</div>
			</div>

			<h3>Others</h3><hr class="sub">

			<div class="amenities">
				<div>
				<input type="checkbox" name="ensuite" value="Yes" id="balcony" class="check"><label for="balcony">Ensuite</label><br>
				</div>

				<div>
				<input type="checkbox" name="carport" value="Yes" id="swpool" class="check"><label for="pool">Carport</label><br>
				</div>

				<div>
				<input type="checkbox" name="garden" value="Yes" id="furnished" class="check"><label for="furnished">Garden</label><br>
				</div>

				<div>
				<input type="checkbox" name="paved" value="Yes" id="furnished" class="check"><label for="furnished">Paved</label><br>
				</div>
			</div>
			<button type="submit" name="refine">Refine</button><br>
		</div><br>
			
		</form>
		</center>
	</div>
</body>
</html>
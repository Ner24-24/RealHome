<?php
		
	include '../connection.php';

	if (isset($_POST["sendcode"])){
		$useremail = $_POST["email"];

		$check = "SELECT * FROM users WHERE email = ?";
		$prep = mysqli_prepare($conn, $check);
		mysqli_stmt_bind_param($prep,"s", $useremail);
		$execcheck = mysqli_execute($prep);
		$res = mysqli_stmt_get_result($prep);

		if (mysqli_num_rows($res) > 0){
			$fetch = mysqli_fetch_assoc($res);
			$user_id = $fetch["user_id"];
			$username = $fetch["username"];

			$token = bin2hex(random_bytes(32));
        	$expire_at = date("Y-m-d H:i:s", strtotime('+1 hour'));

        	$ins = "INSERT INTO password_resets(user_id, token, expire_at) VALUES(?,?,?)";

        	$insprep = mysqli_prepare($conn, $ins);
        	mysqli_stmt_bind_param($insprep,"iss",$user_id, $token, $expire_at);
        	$insexec = mysqli_execute($insprep);
        	sendEmail($useremail, $token);
		}
		else{
			echo "User does not exist, <a href='forgotp.html'>Try again</a> or <a href='signup.html'>Create account</a>";
		}
	}
	
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\SMTP;
	use PHPMailer\PHPMailer\OAuth;
	use League\OAuth2\Client\Provider\Google;

	require_once 'vendor/autoload.php';
	require_once 'class-db.php';

	$mail = new PHPMailer();
	$mail->isSMTP();
	$mail->Host = 'smtp.gmail.com';
	$mail->Port = 465;

	//Set the encryption mechanism to use:
	// - SMTPS (implicit TLS on port 465) or
	// - STARTTLS (explicit TLS on port 587)
	$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;

	$mail->SMTPAuth = true;
	$mail->AuthType = 'XOAUTH2';

	$email = 'naredev24@gmail.com'; // the email used to register google app
	$clientId = '474358052568-9kml9evnrvdiorgfdijn16nue831hlv3.apps.googleusercontent.com';
	$clientSecret = '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';

	$db = new DB();
	$refreshToken = $db->get_refresh_token();

	//Create a new OAuth2 provider instance
	$provider = new Google(
	    [
	        'clientId' => $clientId,
	        'clientSecret' => $clientSecret,
	    ]
	);

	//Pass the OAuth provider instance to PHPMailer
	$mail->setOAuth(
	    new OAuth(
	        [
	            'provider' => $provider,
	            'clientId' => $clientId,
	            'clientSecret' => $clientSecret,
	            'refreshToken' => $refreshToken,
	            'userName' => $email,
	        ]
	    )
	);

	function sendEmail($useremail, $token){
		
		$mail->setFrom($email, "Real Home");
		$mail->addAddress($useremail, $username);
		$mail->isHTML(true);
		$mail->Subject = 'Password reset link for Real Home Account.';
		$mail->Body = "Hey, reset your Real Home account Password <a href='http://localhost/RH/resetpass.php <?php echo $token;?>'>Here</a>";
		//send the message, check for errors
		if (!$mail->send()) {
		    echo 'Mailer Error: ' . $mail->ErrorInfo;
		}
		else{
			echo "Reset password link has been sent to your Email.";
			exit();
		}	
	}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Real Home</title>
	<style type="text/css">
		*{
			font-weight: bold;
		}
		body{
			justify-content: center;
			align-items: center;
			display: flex;
		}
		p{
			font-family: sans-serif;
			font-size: 130px;
		}
		a{
			color: black;
		}
	</style>
</head>
<body>

</body>
</html>
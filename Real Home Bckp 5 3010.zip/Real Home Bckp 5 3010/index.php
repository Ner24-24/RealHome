<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="homes,rent,buildings">
    <meta name="author" content="naredev24@gmail.com">
    <link rel="stylesheet" type="text/css" href="styles/style.css?v=1.0">
    <title>Real Home</title>
</head>
<body>
    <!--top part-->
    <header class="top" id="top">
        <center>
            <h1>Real Home</h1><hr>
            <p>Rent or Buy a REAL HOME</p><!--slogan-->
        </center>
    </header>


    <!--middle part-->
    <div class="middle">
        <center>
        <form id="search" name="look" method="GET" action="results.php">
            <select name="listingtype" class="sel" id="rp" required>
                <option value="Lease" selected>Rent</option>
                <option value="Sell">Purchase</option>
            </select><br><br>

            <input type="search" name="search" placeholder="Search for Properties" required><br>
            <input type="submit" id="results" value="Search">
        </form><br><br>
        <a href="#bottom" class="tomenu">\/</a>
        </center><br>

        <div class="hello">
            <h2>Welcome to <i>Real Home</i></h2>
        </div>
        <center>
        <div class="services">
            <ul>
                <li>
                    <div class="card">
                            <img src="images/buy.jpg" width="100%" height="250px" alt="BUY">
                            <!-- https://www.pexels.com/photo/a-close-up-shot-of-a-person-holding-keys-8112169/ -->
                            <h3>Buy A Real Home</h3>
                            <p>Buy a Real Home suited for You, we help You find homes to choose from according to your needs.</p><br>
                            <a href="#top" class="contact" id="buy">Buy</a>
                    </div>
                </li>
                <li>
                    <div class="card">
                            <img src="images/sell.jpg" width="100%" height="250px" alt="BUY">
                            <!-- https://www.pexels.com/photo/two-people-shaking-hands-13801685/ -->
                            <h3>Sell A Real Home</h3>
                            <p>Sell or Lease a Real Home with us, this includes advertising your property to be viewed by people across the country and definetly find a buyer.</p><br>
                            <a href="addlisting.php" class="contact">Sell</a>
                    </div>
                </li>
                <li>
                    <div class="card">
                            <img src="images/rent.jpg" width="100%" height="250px" alt="BUY">
                            <!-- https://www.pexels.com/photo/man-in-white-t-shirt-and-black-pants-holding-woman-in-white-t-shirt-4554395/ -->
                            <h3>Rent Real Home</h3>
                            <p>Rent a Real Home suited for You, we help You find properties to choose from according to your needs.</p><br>
                            <a href="#top" class="contact" id="rent">Rent</a>
                    </div>
                </li>
            </ul>
            
        </div>
        </center>
    </div>
    <!--bottom part-->
    <footer class="bottom" id="bottom">
        <nav>
        <ul>
            <li><a href="findagents.php">Find Agents</a></li>
            <li><a href="contactus.php">Contact Us</a></li>
            <li>
                <?php
                    session_start();
                    include 'connection.php';
                    if (isset($_SESSION['user_id'])){
                        $user_id = $_SESSION['user_id'];
                        echo "<a href='profilepage.php'>You</a>";
                    }
                    else{
                        echo "<a href='loginpage.html'>Sign In</a>";
                    }
                ?>
            </li>
        </ul>
        </nav>
    </footer>

<script type="text/javascript">
    let rent = document.getElementById("rent");
    let buy = document.getElementById("buy");
    let rp = document.getElementById("rp");

    rent.addEventListener("click", toRent);
    buy.addEventListener("click", toBuy);

    function toRent() {
        rp.value = "Lease";
    }
    function toBuy() {
        rp.value = "Sell";
    }
</script>
</body>
</html>
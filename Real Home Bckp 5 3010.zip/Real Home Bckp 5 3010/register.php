<?php
	include 'connection.php';

	if (isset($_POST['register'])){

		$name = $_POST['fname'];
		$sname = $_POST['lname'];
		$gender = $_POST['gender'];
		$city = $_POST['city'];
		$province = $_POST['province'];
		$email = $_POST['email'];
		$cellp = $_POST['cell'];
		$acctype = $_POST['accounttype'];
		$pass = trim($_POST['password']);
		$verifypass = trim($_POST['verpassword']);

		$check = "SELECT * FROM users WHERE email = '$email'";
		$execcheck = mysqli_query($conn, $check);

		if (mysqli_num_rows($execcheck) > 0){
			echo "This email already exists<br><a href='loginpage.html'>Login</a> or <a href='signup.html'>Use another email</a>";
		}
		else{
			if ($pass == $verifypass){

				//$passw = password_hash($pass, PASSWORD_DEFAULT);
				$insert = "INSERT INTO users (username,surname,gender,email,city,pass,cellno,usertype,province) VALUES(?,?,?,?,?,?,?,?,?)";
				$prep = mysqli_prepare($conn, $insert);
				mysqli_stmt_bind_param($prep, "sssssssss", $name, $sname, $gender, $email, $city, $pass, $cellp, $acctype, $province);
				mysqli_stmt_execute($prep);
				echo "Account created successfully<a href='loginpage.html'>Login</a>";
				mysqli_stmt_close($prep);
				exit();
			}
			else{
				echo "Passwords do not match <a href='signup.html'>Try again</a>";
			}
		}
	}
?>
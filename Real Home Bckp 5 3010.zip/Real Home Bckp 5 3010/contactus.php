<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="styles/contactusstyle.css">
	<title>Real Home</title>
</head>
<body>

	<center>
		<?php
			session_start();
			include "connection.php";

			function isLoggedInemail(){
				
				if (isset($_SESSION["user_id"])){
					$user_id = $_SESSION['user_id'];
					$useremail = $_SESSION['email'];
					return $useremail;
				}
				
				else{
					return "";
				}
			}
			function isLoggedInname(){

				if (isset($_SESSION["user_id"])){
					$username = $_SESSION['username'];
					return $username;
				}
				else{
					return "";
				}
			}
			function isLoggedInCell(){

				if (isset($_SESSION["user_id"])){
					$usercell = $_SESSION['cellno'];
					return $usercell;
				}
				else{
					return "";
				}
			}
		?>
		<div class="signin">
		<center>
			<h1>Contact Us</h1><hr><br>
			<form action="phpmailer/sendemail.php" name="contact" method="POST">
			<input type="text" name="fname" placeholder="Name" required value="<?php echo isLoggedInname(); ?>">
			<input type="Email" name="email" id="email" placeholder="Email" value="<?php echo isLoggedInemail(); ?>" required><br>
			<input type="tel" name="cell" id="cell" placeholder="Cellphone Number" value="<?php echo isLoggedInCell(); ?>" required><br>
			<input type="text" name="subject" id="subject" value="Enquiry" required><br><br>
			<textarea name="message" placeholder="Enter your message here" class="mess" required></textarea>
			<input type="submit" name="send" id="submit" value="Send" class="submit">
			</form>
			<a href="index.php"><</a>
		</center>
		</div>
</body>
</html>
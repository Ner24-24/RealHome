<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale= 1.0">
	<title>Real Home</title>
	<link rel="stylesheet" type="text/css" href="styles/resultsstyle.css?v=1.0">
	<script type="text/javascript" src="scripts/results.js" async defer></script>
</head>
<body>
	<header class="top" id="top">
	<h1>Real Home</h1>
	<nav class="bottom">
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="contactus.html">Contact Us</a></li>
			<li>
				<?php
					session_start();
					include 'connection.php';
					if (isset($_SESSION["user_id"])){
						$user_id = $_SESSION['user_id'];
						echo "<a href='profilepage.php'>You</a>";
					}
					else{
						echo "<a href='loginpage.html'>Sign In</a>";
					}
				?>
			</li>
		</ul>
	</nav>
	</header><br>
	<div class="middle" id="middle">
		<center>
			<?php $selectedtype = $_GET['listingtype'];?>
			<form name="searchfor" action="results.php" method="GET">
				<select name="listingtype" id="rp" required>
		            <option value="Lease" <?php echo ($selectedtype == "Lease") ? "selected" : ""; ?>>Rent</option>
		            <option value="Sell" <?php echo ($selectedtype == "Sell") ? "selected" : ""; ?>>Purchase</option>
        		</select><br><br>
				<input type="search" name="search" placeholder="Search for properties" value="<?php echo $_GET["search"]; ?>"><br>
				<button type="submit" id="results" name="search">Search</button><br><br>
			</form>
			<button id="filter" class="filter" name="filter">Filter</button>
		</center>
		<?php
			$filtertype = isset($_GET['type']) ? $_GET['type'] : '';
			$filterfurnished = isset($_GET['furnished']) ? $_GET['furnished'] : '';
			$filterprice = isset($_GET['price']) ? $_GET['price'] : '';
			$filterbeds = isset($_GET['bedrooms']) ? $_GET['bedrooms'] : '';
			$filterbaths = isset($_GET['bathrooms']) ? $_GET['bathrooms'] : '';
			$filterstories = isset($_GET['stories']) ? $_GET['stories'] : '';
			$filtergarages = isset($_GET['garages']) ? $_GET['garages'] : '';
			$filterpool = isset($_GET['pool']) ? $_GET['pool'] : '';
			$filterbalcony = isset($_GET['balcony']) ? $_GET['balcony'] : '';
			$filterensuite = isset($_GET['ensuite']) ? $_GET['ensuite'] : '';
			$filtercarport = isset($_GET['carport']) ? $_GET['carport'] : '';
			$filtergarden = isset($_GET['garden']) ? $_GET['garden'] : '';
			$filterpaved = isset($_GET['paved']) ? $_GET['paved'] : '';

			$filtersql = "SELECT proptype, price, ensuite, furnished, balcony, carport, garden, paved, bedrooms, bathrooms, garages, stories, pool FROM properties WHERE 1=1";

			if (!empty($filtertype)) {
			    $filtersql .= " AND proptype LIKE '%" . mysqli_real_escape_string($conn, $filtertype) . "%'";
			}
			if (!empty($filterprice)) {
			    $filtersql .= " AND price <= " . floatval($filterprice);
			}
			if (!empty($filterbeds)) {
			    $filtersql .= " AND bedrooms = " . intval($filterbeds);
			}
			if (!empty($filterbaths)) {
			    $sql .= " AND bathrooms = " . intval($filterbaths);
			}
			if (!empty($filterstories)) {
			    $filtersql .= " AND stories = " . intval($filterstories);
			}
			if (!empty($filtergarages)) {
			    $filtersql .= " AND garages = " . intval($filtergarages);
			}
			if (!empty($filterpool)) {
			    $filtersql .= " AND pool = " . $filterpool;
			}
			if (!empty($filterensuite)) {
			    $filtersql .= " AND ensuite = " . intval($filterensuite);
			}
			if (!empty($filterbalcony)) {
			    $filtersql .= " AND balcony = " . intval($filterbalcony);
			}
			if (!empty($filterpaved)) {
			    $filtersql .= " AND paved = " . intval($filterpaved);
			}
			if (!empty($filtergarden)) {
			    $filtersql .= " AND garden = " . intval($filtergarden);
			}
			if (!empty($filtercarport)) {
			    $filtersql .= " AND carport = " . intval($filtercarport);
			}

			$prep = mysqli_prepare($conn,$filtersql);
			mysqli_stmt_execute($prep);
			$res = mysqli_stmt_get_result($prep);

			if (mysqli_num_rows($res) > 0){
			
				while ($fetch = mysqli_fetch_assoc($res)){
					$propid = $fetch["prop_id"];
					$lister = $fetch["user_id"];
					$propname = $fetch["name"];
					$propprice = $fetch["price"];
					$proptype = $fetch["proptype"];
					$beds = $fetch["bedrooms"];
					$baths = $fetch["bathrooms"];

					$lister = "SELECT * FROM users WHERE user_id = '$lister'";
					$execlister = mysqli_query($conn, $lister);
					$fetchlister = mysqli_fetch_assoc($execlister);
					$listername = $fetchlister["username"];
					$surname = $fetchlister["surname"];				
					$lstimgstmt = "SELECT filename FROM images WHERE prop_id = ?";
					$lstimgprep = mysqli_prepare($conn, $lstimgstmt);
					mysqli_stmt_bind_param($lstimgprep,"i", $propid);
					mysqli_stmt_execute($lstimgprep);
					$lstimgres = mysqli_stmt_get_result($lstimgprep);
					if (mysqli_num_rows($lstimgres) > 0){
						$imgfetch = mysqli_fetch_assoc($lstimgres);
						$img = $imgfetch["filename"];
						$imgpath = "./propimages/" . basename($img);

						echo "<a href=\"property.php?propid=" . urlencode($propid) . "\">
							<div class='prop'>
							<div class='img'>
								<img src='$imgpath'>
							</div>
							<div class='info'>
								<h3 id='pname'>$propname</h3>
								<p id='status'>$proptype</p>
								<p id='aname'>Listed By $listername $surname</p>
								<p id='price'>R$propprice</p>
								<p>Bedrooms: $beds</p>
								<p>Bathrooms: $baths</p>
							</div><br>
						</div></a><br>";
					}}
			}
			else{
				echo "
				<center>
					<p style='font-size: 30px;'>No Properties found</p>
				</center";
			}
		?>
		
	</div>
	
	<div class="filterbox" id="filterbox">
		<center>
		<button class="back" id="back">X</button>
		<h2>Refine Results</h2><hr><br>
		<form name="refine" action="filteredresults.php" method="GET">
			<select id="proptype" name="type" class="sel">
				<option>Property type</option>
				<option value="Apartment" id="aparment">Apartment</option>
				<option value="House" id="house">House</option>
				<option value="Commercial" id="commercial">Commercial</option>
				<option value="Plot" id="plot">Plot</option>
				<!--Include PHP code for all types from database on testing-->
			</select>
			<input type="Number" name="price" placeholder="Max Price" class="sel" value="<?php echo $filterbeds; ?>">

			<div class="primary">
				<div>
					<label for="bedrooms">Bedrooms</label>
					<input type="Number" name="bedrooms" id="bedrooms" class="bedrooms"  min="0" max="99" value="<?php echo $filterbeds; ?>"><br>
				</div>

				<div>
					<label for="bathrooms">Bathrooms</label>
					<input type="Number" name="bathrooms" id="bathrooms"  min="0" max="99" value="<?php echo $filterbaths; ?>"><br>
				</div>

				<div>
					<label for="garages">Garages</label>
					<input type="Number" name="garages" id="garages"  min="0" max="99" value="<?php echo $filtergarages; ?>"><br>
				</div>

				<div>
					<label for="stories">Stories</label>
					<input type="Number" name="stories" id="stories"  min="0" max="99" value="<?php echo $filterstories; ?>"><br>
				</div>
			</div>

			<h3>Amenities</h3><hr class="sub">

			<div class="amenities">
				<div>
				<input type="checkbox" name="pool" value="Yes" id="swpool" class="check" value="<?php echo $filterpool; ?>"><label for="pool">Pool</label><br>
				</div>

				<div>
				<input type="checkbox" name="balcony" value="Yes" id="balcony" class="check" value="<?php echo $filterbalcony; ?>"><label for="balcony">Balcony</label><br>
				</div>

				<div>
				<input type="checkbox" name="furnished" value="Yes" id="furnished" class="check" value="<?php echo $filterfurnished; ?>"><label for="furnished">Furnished</label><br>
				</div>
			</div>

			<h3>Others</h3><hr class="sub">

			<div class="amenities">
				<div>
				<input type="checkbox" name="ensuite" value="Yes" id="balcony" class="check" value="<?php echo $filterensuite; ?>"><label for="balcony">Ensuite</label><br>
				</div>

				<div>
				<input type="checkbox" name="carport" value="Yes" id="swpool" class="check" value="<?php echo $filtercarport; ?>"><label for="pool">Carport</label><br>
				</div>

				<div>
				<input type="checkbox" name="garden" value="Yes" id="furnished" class="check" value="<?php echo $filtergarden; ?>"><label for="furnished">Garden</label><br>
				</div>

				<div>
				<input type="checkbox" name="paved" value="Yes" id="furnished" class="check" value="<?php echo $filterpaved; ?>"><label for="furnished">Paved</label><br>
				</div>
			</div>

			</div><br>
			<button type="submit" name="refine">Refine</button><br>
		</form>
		</center>
	</div>
</body>
</html>
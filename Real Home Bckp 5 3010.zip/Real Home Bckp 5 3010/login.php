<?php
include 'connection.php';

if (isset($_POST['loginb'])) {
    $email = $_POST['email'];
    $pass = trim($_POST['logpass']);

    $check = "SELECT * FROM users WHERE email = ?";
    $prep = mysqli_prepare($conn, $check);
    mysqli_stmt_bind_param($prep, "s", $email);
    mysqli_stmt_execute($prep);
    $execcheck = mysqli_stmt_get_result($prep);

    if (mysqli_num_rows($execcheck) > 0) {
        $assoc = mysqli_fetch_assoc($execcheck);
        $user_id = $assoc["user_id"];
        $username = $assoc["username"];
        $useremail = $assoc["email"];
        $usercell = $assoc["cellno"];
        $passw = $assoc["pass"];
        $decrypt = password_verify($pass, $passw);

        if ($pass == $passw) {
            session_start(); // Start session before any output
            $_SESSION['user_id'] = $user_id;
            $_SESSION['username'] = $username;
            $_SESSION['email'] = $useremail;
            $_SESSION['cellno'] = $usercell;
            echo "Logged in";
            header("Location: profilepage.php");
            exit(); // Ensure no further code is executed after redirect
        } else {
            echo "Invalid Password, <a href='loginpage.html'> Try Again</a>";
            //$decrypt";
            // echo "Password Valid: " . ($decrypt ? "true" : "false") . "<br>";
        }
    } else {
        echo "Invalid login credentials, <a href='loginpage.html'>Try Again</a> or <a href='signup.html'>Register an account :)</a>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Real Home</title>
    <style type="text/css">
        *{
            font-weight: bold;
        }
        body{
            justify-content: center;
            align-items: center;
            display: flex;
        }
        p{
            font-family: sans-serif;
            font-size: 130px;
        }
        a{
            color: black;
        }
    </style>
</head>
<body>

</body>
</html>
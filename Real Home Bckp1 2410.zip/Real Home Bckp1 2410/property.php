<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Real Home</title>
	<link rel="stylesheet" type="text/css" href="styles/propertystyle.css?v=1.0">
	
	<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
     integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY="
     crossorigin=""/>
     <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
     integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo="
     crossorigin=""></script>
</head>
<body>
	<header class="top">
		<h1>Real Home</h1>
		<nav class="bottom">
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="contactus.php">Contact Us</a></li>
				<li>
					<?php
						session_start();
						include "connection.php";
						if (isset($_SESSION['user_id'])){
							echo "<a href='profilepage.php'>You</a>";
						}
						else{
							echo "<a href='loginpage.html'>Sign in</a>";
						}
					?>
				</li>
			</ul>
		</nav>

	</header><br><br>

	<div class="middle">

		<a href="results.php" class="backtores"><--Back to Results</a><br>
		<div class="propbox">
			<div class="propimg">
				<img src="https://images.pexels.com/photos/277667/pexels-photo-277667.jpeg?auto=compress&cs=tinysrgb&w=600&lazy=load" height="100%" id="gallery" width="100%" alt="">
				<button id="prev" class="buttons"><</button>
				<button id="next" class="buttons">></button>
			</div>
			<p id="tofloat">Property Name</p>
			<p id="status">Status</p>
			<p id="tofloat">R000 000 000 000</p>
			<p id="location">Location</p><br>
			<a href="https://www.google.com/maps/@?api=1&map_action=map&center=-27.567556, 25.567576&zoom=15" target="_blank">
    			View in Google Maps</a>
			<p>Details</p><!---27.567556, 25.567576-->

		<ul class="details">
				<li>Bedrooms: <!--From Database--></li>
				<li>Bathrooms: <!--From Database--></li>
				<li>Garage: <!--From Database--></li>
				<li>Stories: <!--From Database--></li>
				<li>Furnished: <!--From Database--></li>
				<li>Kitchen: <!--From Database--></li>
				<li>Car Port: <!--From Database--></li>
				<li>Fenced: <!--From Database--></li>
				<li>Garden: <!--From Database--></li>
				<li>Water: <!--From Database--></li>
			</ul>
			<p>Description</p>
			<p class="desc" id="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
			<button class="showmore" id="showmore">+ Show more</button><hr><br>
			<center>
			<div class="agent">
				<div class="img"><img src="images/thapelo.jpg" height="100%" width="100%"></div>
				<p>Name</p>
				<p>Company Name</p>
				<p class="contact">Contact</p>
			</div><br>
			</center>
		</div>
	</div>
	<div class="mapcont" id="mapcont">
		<button class="mapbutton">X</button>
		<div id="map" class="map">
			
		</div>	
	</div>
</body>

<script type="text/javascript">
	let prevBtn = document.getElementById("prev");
	let nextBtn = document.getElementById("next");
	let gall = document.getElementById("gallery");
	let images = ["image1.jpg", "image2.jpg"];

	let currentIndex = 0;

	function prevIm() {
		if (currentIndex === 0){
			currentIndex = images.length - 1;
		}
		else{
			currentIndex = currentIndex - 1;
		}
		gall.src = images[currentIndex];
	}
	prevBtn.addEventListener("click", prevIm)

	function nextIm() {
		if (currentIndex === images.length - 1){
			currentIndex = 0;
		}
		else{
			currentIndex = currentIndex + 1;
		}
		gall.src = images[currentIndex];
	}
	nextBtn.addEventListener("click", nextIm)
</script>
<script type="text/javascript">
	let descBtn = document.getElementById('showmore');
	let desc = document.getElementById('desc');
	
	descBtn.addEventListener("click",showmore);

	function showmore() {
		if (desc.style.overflow === "hidden"){
			desc.style.height = "auto";
			desc.style.overflow = "visible";
			desc.style.animation = "showmore 1s";
			desc.style.opacity = "100%";
			descBtn.innerHTML = "- Show Less";
		}else{
			desc.style.height = "40px";
			desc.style.overflow = "hidden";
			desc.style.animation = "when";
			desc.style.opacity = "50%";
			descBtn.innerHTML = "+ Show more";
		}
	}
</script>
<script type="text/javascript">
	let prop = document.querySelectorAll(".top, .middle, .bottom");
	let showloc = document.getElementById("location");
	let closeMapB = document.querySelector(".mapbutton");
	let mapDiv = document.getElementById("mapcont");
	showloc.addEventListener("click",openMap);
	closeMapB.addEventListener("click", closeMap);


	let map = L.map('map').setView([-27.567556, 25.567576], 15);
	L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
	}).addTo(map);

	L.marker([-27.567556, 25.567576]).addTo(map);

	function openMap() {
		if (mapDiv.style.visibility === "hidden"){
		mapDiv.style.visibility = "visible";
		prop.forEach(function (element) {
			element.style.visibility = "hidden";
		});
		}
		else{
			mapDiv.style.visibility = "hidden";
			prop.forEach(function (element) {
				element.style.visibility = "visible";
			});
	}
	}
	function closeMap(element) {
		if (mapDiv.style.visibility === "visible"){
			mapDiv.style.visibility = "hidden";
			prop.forEach(function (element) {
	    	element.style.visibility = "visible";
		});
		}
		else{
			mapDiv.style.visibility = "visible";
			prop.forEach(function (element) {
	    	element.style.visibility = "hidden";
		});
		}
	}
</script>
</html>
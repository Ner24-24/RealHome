<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Real Home</title>
	<link rel="stylesheet" type="text/css" href="styles/profilepagestyle.css">
</head>
<body>
	<div class="top">
		<h1>Real Home</h1>
		<nav class="bottom">
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="contactus.php">Contact Us</a></li>
				<li><a href="findagents.php">Find Agents</a></li>
			</ul>
		</nav>
	</div>

	<div class="middle">
		<?php
			session_start();
			include "connection.php";
			if(isset($_SESSION['user_id'])){
				$user_id = $_SESSION['user_id'];
			}
			else{
				header("Location: loginpage.html");
			}
		?>
		<?php
			$fetchstmt = "SELECT * FROM users WHERE user_id = ?";
			$prep = mysqli_prepare($conn,$fetchstmt);
			mysqli_stmt_bind_param($prep,"s", $user_id);
			mysqli_stmt_execute($prep);
			$res = mysqli_stmt_get_result($prep);

			if (mysqli_num_rows($res) > 0){
				$fetch = mysqli_fetch_assoc($res);
				$name = $fetch["username"];
				$useremail = $fetch["email"];
				$cell = $fetch["cellno"];
				$imgname = $fetch["profileimg"];
				$img = "./userimages/" . $imgname;
			}

			function displayImage($imgname,$img){
				if (empty($imgname)){
					return "images/avatar.jpg";
				}
				else{
					return "$img";
				}
			}
		?>
		<div>
			<center>
			<div class="img">
				<img src="<?php echo displayImage($imgname,$img)?>" alt="You" width="100%" height="100%">
			</div>
			<p id="name">
				<?php
					echo "Welcome $name";
				?>
			</p>
			<p id="listings">Listings: 0</p>
			<p id="email">Email: <?php echo "$useremail"; ?></p>
			<p id="cellnums">Phone Number: <?php echo "$cell"; ?></p>
			<p id="agency">Agency: None</p>
			<button><a href="addlisting.php">Add a listing</a></button><br>
				<h2>Change Details</h2><hr class="ch">
				<p>Note: Verification will be required</p>
			<form name="changepp" action="changepicture.php" enctype="multipart/form-data" method="POST">
				<label for="pp" class="changelab">
					Click Here to Change Profile Picture
					<input type="file" name="pp" id="pp" placeholder="New Email" style="visibility: hidden;" accept=".png,.jpg,.jpeg" required>
				</label><br>
				<button type="submit" name="changepp" class="change">Change</button><br>
			</form><br>
			<!-- Change details form -->
			<form name="changedet" action="changedetails.php" method="POST">
				<input type="email" name="email" placeholder="New Email">
				<button type="submit" name="changeem" class="change">Change</button><br>
				<input type="tel" name="cellno" placeholder="New Phone Number" pattern="[0-9]{3}[0-9]{3}[0-9]{4}">
				<button type="submit" name="changecellno" class="change">Change</button><br>
				<input type="text" name="agency" placeholder="Change Agency">
				<button type="submit" name="changeag" class="change">Change</button><br><br><br>
			</form>
			<form name="logoutform" action="logout.php" method="POST">
				<button type="submit" name="logout" class="change">Log Out</button>
			</form>
			</center>
		</div>
			<center>
			<h2>Favorites: <!--Number from database--></h2><hr>
			</center>
			<div class="favorites">
				<ul>
					<li>
						<center>
						<div class="propbox">
							<img src="images/thapelo.jpg" width="100%" height="100%">
							<h3>Property Name</h3>
							<p>Price</p>
							<p class="status">Status</p>	
						</div>
						</center>
					</li>
				</ul>
			</div>

			<center>
			<h2>Your Listings: <!--Number from database--></h2><hr>
			</center>
			<div class="favorites">
				<ul>
					<li>
						<center>
						<div class="propbox">
							<img src="images/thapelo.jpg" width="100%" height="100%">
							<h3>Property Name</h3>
							<p>Price</p>
							<p class="status">Status</p>	
						</div>
						</center>
					</li>
				</ul>
			</div>
	</div>
</body>
</html>
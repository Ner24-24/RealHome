<?php
	session_start();
	include "connection.php";

	if (isset($_POST['submit'])){
		$proptype = $_POST['proptype'];
		$listingtype = $_POST['listingtype'];
		$listingdate = $_POST['date'];
		$propname = $_POST['propname'];
		$propaddress = $_POST['propaddress'];
		$suburb = $_POST['suburb'];
		$numbedrooms = $_POST['bedrooms'];
		$numbathrooms = $_POST['bathrooms'];
		$garages = $_POST['garages'];
		$stories = $_POST['stories'];
		$price = $_POST['propprice'];
		$area = $_POST['area'];
		$description = $_POST['description'];
		$furnished = $_POST['furnished'];
		$kitchen = $_POST['kitchen'];
		$lounge = $_POST['lounge'];
		$dining = $_POST['dining'];
		$balcony = $_POST['balcony'];
		$carport = $_POST['carport'];
		$carportno = $_POST['nocarport']
		$parking = $_POST['parking'];
		$pavement = $_POST['paved'];
		$garden = $_POST['garden'];
		$fenced = $_POST['fenced'];
		$water = $_POST['water'];
		$electricity = $_POST['electricity'];
		$pool = $_POST['pool'];
		$ensuite = $_POST['ensuite'];
		$listerid = $_POST['listerid'];

		
		echo "
			$proptype<br>
			$listingtype<br>
			$listingdate<br>
			$propname<br>
			$propaddress<br>
			$suburb<br>
			$numbedrooms<br>
			$numbathrooms<br>
			$garages<br>
			$stories<br>
			$price<br>
			$area<br>
			$furnished<br>
			$kitchen<br>
			$lounge<br>
			$dining<br>
			$balcony<br>
			$carport<br>
			$parking<br>
			$pavement<br>
			$garden<br>
			$fenced<br>
			$water<br>
			$electricity<br>
			$pool<br>
			$ensuite<br>
			Lister id: $listerid<br>
			";
	}
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<style type="text/css">
		body{
			color: black;
		}
	</style>
</head>
<body>

</body>
</html>
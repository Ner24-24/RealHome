<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Real Home</title>
	<link rel="stylesheet" type="text/css" href="styles/contactagentstyle.css">
</head>
<body>
	<header class="top">
			<h1><i>Real Home</i></h1>
	</header>
	<nav class="bottom">
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="contactus.php">Contact Us</a></li>
			<li><a href="loginpage.html">
				<?php
					session_start();
					include "connection.php";

					if (isset($_SESSION["user_id"])){
						$user_id = $_SESSION["user_id"];
						$useremail = $_SESSION["email"];
						echo "<a href='profilepage.php'>You</a>";
					}
					else{
						echo "<a href='loginpage.html'>Sign in</a>";
					}
				?>
			</li>
		</ul>
	</nav>
	<div class="middle">
			<center>
				<div class="img">
					<img src="https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=600" width="100%" height="100%">
				</div>
				<p id="name"><?php echo "$listername"; ?></p>
				<p id="agency">Agency: Function</p>
				<a href="<?php echo "$listermail";?>">Email Me</a>
				<a href="tel:+<?php echo "$litsercellno"; ?>">Call Me</a>
			</center>
	</div><br>
</body>
</html>
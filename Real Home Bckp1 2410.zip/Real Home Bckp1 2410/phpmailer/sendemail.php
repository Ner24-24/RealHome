<?php
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\SMTP;
	use PHPMailer\PHPMailer\OAuth;
	use League\OAuth2\Client\Provider\Google;


	require_once 'vendor/autoload.php';
	require_once 'class-db.php';

	$mail = new PHPMailer();
	$mail->isSMTP();
	$mail->Host = 'smtp.gmail.com';
	$mail->Port = 465;

	//Set the encryption mechanism to use:
	// - SMTPS (implicit TLS on port 465) or
	// - STARTTLS (explicit TLS on port 587)
	$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;

	$mail->SMTPAuth = true;
	$mail->AuthType = 'XOAUTH2';

	$email = 'naredev24@gmail.com'; // the email used to register google app
	$clientId = '474358052568-9kml9evnrvdiorgfdijn16nue831hlv3.apps.googleusercontent.com';
	$clientSecret = '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';

	$db = new DB();
	$refreshToken = $db->get_refresh_token();

	//Create a new OAuth2 provider instance
	$provider = new Google(
	    [
	        'clientId' => $clientId,
	        'clientSecret' => $clientSecret,
	    ]
	);

	//Pass the OAuth provider instance to PHPMailer
	$mail->setOAuth(
	    new OAuth(
	        [
	            'provider' => $provider,
	            'clientId' => $clientId,
	            'clientSecret' => $clientSecret,
	            'refreshToken' => $refreshToken,
	            'userName' => $email,
	        ]
	    )
	);
	session_start();
	include '../connection.php';
	if (isset($_SESSION['user_id'])){
		$useremail = $_SESSION['email'];
	}
	else{
		$useremail = $_POST['email'];
	}
	$message = $_POST['message'];
	$name = $_POST['fname'];

	$mail->setFrom($useremail, $name);
	$mail->addAddress('naredev24@gmail.com');
	$mail->isHTML(true);
	$mail->Subject = "Enquiry from $name";
	$mail->Body = "$message, From $useremail";

	//send the message, check for errors
	if (!$mail->send()) {
	    echo 'Mailer Error: ' . $mail->ErrorInfo;
	} else {
	    echo 'Message sent!, Back to <a href="../index.php">Home</a>';
	}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Real Home</title>
	<style type="text/css">

		@font-face{
		font-family: play;
		src: url(../fonts/Play-Bold.ttf) format('woff2');
		}
		*{
			font-weight: bold;
			font-family: play;
		}
		body{
			justify-content: center;
			align-items: center;
			display: flex;
			font-size: 40px;
			animation: backcol 3s infinite;
		}
		@keyframes backcol{
			0%{background-color: white;}
			50%{background-color: #7F9F80;}
			75%{background-color: gray;}
			100%{background-color: white;}
		}
		p{
			font-family: play;
		}
		a{
			color: black;
		}
		@media (max-width: 720px){
			body{
				font-size: 20px;
			}
		}
	</style>
</head>
<body>

</body>
</html>
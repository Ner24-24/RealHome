<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Real Home</title>
	<link rel="stylesheet" type="text/css" href="styles/addlistingmedia.css?v=1.0">
	<script type="text/javascript">
		//for image name
	</script>
</head>
<body>
	<header>
		<h1>Real Home</h1>
		<nav >
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="contactus.php">Contact</a></li>
				<li>
					<?php
						session_start();
						include "connection.php";
						if (isset($_SESSION["user_id"])){
							echo "<a href='profilepage.php'>You</a>";
						}
						else{
							header("Location: loginpage.html");
						}
					?>
				</li>
			</ul>
		</nav>
	</header><br>

	<center>
	<form action="addmedia.php" enctype="multipart/form-data" name="enterpropmedia" method="POST">
		<div class="mediaupload">
			<h1>Upload Media</h1>
			<p>Upload Images of the property</p><br>
			<label for="uploadmedia" id="uploadlabel">
				<input type="file" name="uploadmedia" id="uploadmedia" accept=".png, .jpg, .jpeg" multiple required style="display: none;">Select Image
			</label><br><br>
			<input type="submit" name="upload" class="submit" value="Upload"><hr>
			<input type="submit" name="submit" class="submit" value="Done"><br>
		</div>
	</form>
	</center>
	<div class="mediapreview">
		<center>
		<h2>Preview Images</h2>
		<ul>
			<li>
				<div class="previm">
					<img src="images/sell.jpg" width="100%" height="100%">
					<form name="delete" action="media.php">
						<input type="button" name="delete" class="delete" value="Delete">
					</form>
				</div>
			</li>
			<li>
				<div class="previm">
					<img src="images/sell.jpg" width="100%" height="100%">
					<form name="delete" action="media.php">
						<input type="button" name="delete" class="delete" value="Delete">
					</form>
				</div>
			</li>
			<li>
				<div class="previm">
					<img src="images/sell.jpg" width="100%" height="100%">
					<form name="delete" action="media.php">
						<input type="button" name="delete" class="delete" value="Delete">
					</form>
				</div>
			</li>
			<li>
				<div class="previm">
					<img src="images/sell.jpg" width="100%" height="100%">
					<form name="delete" action="media.php">
						<input type="button" name="delete" class="delete" value="Delete">
					</form>
				</div>
			</li>
			<li>
				<div class="previm">
					<img src="images/sell.jpg" width="100%" height="100%">
					<form name="delete" action="media.php">
						<input type="button" name="delete" class="delete" value="Delete">
					</form>
				</div>
			</li>
		</ul>
	</center>
	</div>
</body>
</html>